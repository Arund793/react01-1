export default function MyButton(){
    return(
    <button>I'm My Button component</button>
    )
  }
  