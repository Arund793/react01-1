export default function AboutPage(){
    return(
        <><h1>About Page</h1>
        <p>Hello!!</p>
        </>
    )
}