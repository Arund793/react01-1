function Button1(){
    return(
        <button>Button1</button>
        )
}
function Button2(){
    return(
        <button>Button2</button>
        )
}
function Button3(){
    return(
        <button>Button3</button>
        )
}

export{ Button1, Button2, Button3 }